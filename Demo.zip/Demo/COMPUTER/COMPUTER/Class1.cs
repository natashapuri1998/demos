﻿using System;

namespace COMPUTER
{
    public class Software
    {
        string AppType;
        string AppName;
        int AppVer;
        public Software(string AppType,string AppName,int AppVer)
        {
            this.AppType = AppType;
            this.AppName = AppName;
            this.AppVer = AppVer;
        }

        public string Display()
        {
            return $"Application Type={AppType} Name={AppName} Version={AppVer}";
        }
    }
}
