﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateTimeAndStringAPI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"System Date and Time : { DateTime.Now}");
            Console.WriteLine($"System Date : {DateTime.Now.Date.ToString("dd-MM-yyyy")}");
            Console.WriteLine($"Day : {DateTime.Now.Date.Day}");
            Console.WriteLine($"Month : {DateTime.Now.Date.Month}");
            Console.WriteLine($"Year: {DateTime.Now.Date.Year}");
            Console.WriteLine($"After adding 5 days : { DateTime.Now.Date.AddDays(5).ToString("dd-MM-yyyy")}");
            DateTime myDate = new DateTime(2019,10,14);
           int no= myDate.CompareTo(DateTime.Now.Date);
            if(no == 0)
            {
                Console.WriteLine($"{myDate.Date.ToString("dd-MM-yyyy")} and {DateTime.Now.Date.ToString("dd-MM-yyyy")}Both dates are equal");
            }
            else if (no == 1)
            {
                Console.WriteLine($"{myDate.Date.ToString("dd-MM-yyyy")} is newer than {DateTime.Now.Date.ToString("dd-MM-yyyy")}");
            }
            else
            {
                Console.WriteLine($"{myDate.Date.ToString("dd-MM-yyyy")} is older than {DateTime.Now.Date.ToString("dd-MM-yyyy")}");
            }

            double date1=myDate.Date.ToOADate(); //31-12-1899 starting date of OA date
            double date2 = DateTime.Now.Date.ToOADate();
            double days = date2 - date1;
            Console.WriteLine($"Span is days : {days}");
            Console.ReadLine();
        }
    }
}
