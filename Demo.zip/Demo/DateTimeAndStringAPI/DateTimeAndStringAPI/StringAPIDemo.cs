﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateTimeAndStringAPI
{
    class StringAPIDemo
    {
        static void Main()
        {

            //int[] i = new int[10];
            //Console.WriteLine(i.Rank);


            string str = "    Welcome to String Class    ";
            string str1 = String.Copy(str);
            //char[] chars = str1.ToCharArray();
            //int count = str.Length - 1;
            //str.CopyTo(0,chars,0,count;
            
            Console.WriteLine(str1);
            string toSearch = "wElCome";
            if(str.StartsWith(toSearch, StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Yes");
            }
            string newstr= str.Substring(8, 15);
            Console.WriteLine($"Sub String is : {newstr}");
            string newMystr = String.Empty;
            foreach (string s in str.Split(' '))
            {
                newMystr += s;
              
            }
            Console.WriteLine($"str after removing white spaces:{newMystr}");
            Console.ReadLine();
        }
    }
}
