﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class StudentCollDemo
    {
        static void Main()
        {
            List<Student> students = new List<Student>()
            {
                new Student { RollNo = 100, Name = "Scott" },
            new Student { RollNo = 101, Name = "Tiger" }
        };
            foreach(Student std in students)
            {
                Console.WriteLine($"Roll No is {std.RollNo} and Name is {std.Name}");
            }
           // Console.ReadLine();
        }
    }
}
