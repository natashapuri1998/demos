﻿using System;
using System.Collections;


namespace Chapter5
{
    class QueueDemo
    {
        static void Main()
        {
            Queue book = new Queue();
            book.Enqueue(123);
            book.Enqueue(124);
            book.Enqueue(125);

            foreach(var temp in book)
            {
                Console.WriteLine(temp);
            }

            Console.WriteLine("After Removing {0}", book.Dequeue());
            foreach (var temp in book)
            {
                Console.WriteLine(temp);
            }
            Console.WriteLine("Next Element to be removed {0}", book.Peek());

            Console.WriteLine("*******************Stack************************");
            Stack stk = new Stack();
            stk.Push(123);
            stk.Push(124);
            stk.Push(125);


            foreach (var temp in stk)
            {
                Console.WriteLine(temp);
            }


            Console.WriteLine("After Removing {0}", stk.Pop());
            foreach (var temp in stk)
            {
                Console.WriteLine(temp);
            }
            Console.WriteLine("Next Element to be removed {0}", stk.Peek());

        }
    }
}
