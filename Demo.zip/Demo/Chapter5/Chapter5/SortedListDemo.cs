﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class SortedListDemo
    {
        static void Main()
        {
            SortedList<int, string> mysortedList = new SortedList<int, string> { { 1, "One" }, { 10, "Ten" }, { 2, "Two" }, { 100, "Hundred" } };
            Console.WriteLine($"Count is {mysortedList.Count}");
            foreach (int key in mysortedList.Keys)
            {
                Console.WriteLine($"Key is {key} and Value is {mysortedList[key]}");
            }
            if (mysortedList.Remove(10))
            {
                Console.WriteLine($"After removing 10 Count is {mysortedList.Count}");
            }
            foreach (int key in mysortedList.Keys)
            {
                Console.WriteLine($"Key is {key} and Value is {mysortedList[key]}");
            }
        }
        
         
        
    }
}
