﻿using System;
using System.Collections;


namespace Chapter5
{
    class HashTableDemo
    {
        static void Main()
        {
            Hashtable GST = new Hashtable();
            GST.Add("maharashtra", 27);
            GST.Add("gujarat",24);
            GST.Add("delhi", 12);
            string state = "gujarat";
            if(GST[(state).ToLowerInvariant()]==null)
            {
                Console.WriteLine("Invalid State");

            }
            else
            {
                Console.WriteLine("GST Code for Gujarat is {0}", GST[(state).ToLowerInvariant()]);
            }

            GST["delhi"] = 11;
            Console.WriteLine("GST Code for delhi is {0}", GST[("delhi").ToLowerInvariant()]);

            foreach(var v in GST.Keys)
            {
                Console.WriteLine("Key={0} and Value={1}",v,GST[v]);
            }

            GST.Remove("delhi");
            Console.WriteLine("Aftre Removing delhi");

            foreach (var v in GST.Keys)
            {
                Console.WriteLine("Key={0} and Value={1}", v, GST[v]);
            }


        }




    }
}
