﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] nums = { 10, 20, 30, 40, 50 };
            int[] nums1 = new int[] { 10, 20, 30, 40, 50 };
            Console.WriteLine("Enter number of values in array");
            int no = Convert.ToInt32(Console.ReadLine());
            int[] nums2 = new int[no];
            for(int i=0;i<no;i++)
            {
                nums2[i] = Convert.ToInt32(Console.ReadLine());
            }
            foreach(int temp in nums2)
            {
                Console.WriteLine(temp);
            }
            Console.ReadLine();
            Console.WriteLine("Size of nums1 is {0}", nums1.Length);
            
        }
    }
}
