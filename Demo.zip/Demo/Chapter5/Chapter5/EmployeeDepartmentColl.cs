﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class EmployeeDepartmentColl
    {
        static void Main()
        {
            Dictionary<Department, Employee> de = new Dictionary<Department, Employee>()
            {
                { new Department{ DepartmentCode=101},new Employee{ EmployeeCode=1,Name="Scott",DepartmentCode=101} },
                { new Department{ DepartmentCode=102},new Employee{ EmployeeCode=2,Name="Tiger",DepartmentCode=102} }
            };

            foreach (var v in de.Keys)
            {
                Console.WriteLine($"Key : Department Code is {v.DepartmentCode} Values : EmpCode is {de[v].EmployeeCode} Employee Name is {de[v].Name} Department Code is {de[v].DepartmentCode}");
            }
        }
    }
}
