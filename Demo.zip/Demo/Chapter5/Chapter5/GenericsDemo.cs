﻿using System;
using System.Collections.Generic;

namespace Chapter5
{
    class GenericsDemo
    {
        static void Main()
        {
            Queue<int> q = new Queue<int>();
            q.Enqueue(12);
            //q.Enqueue("sdew");  error

            Stack<int> stk = new Stack<int>();
            stk.Push(10);
            stk.Push(20);
           // stk.Push("abc");  error
        }
    }
}
