﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class Employee
    {
        public int EmployeeCode { get; set; }
        public string Name { get; set; }
        public int DepartmentCode { get; set; }
    }
}
