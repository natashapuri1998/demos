﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class DictionaryDemo
    {
        static void Main()
        {
           // List<int> mylist = new List<int>() { 11,22,33,44};
            Dictionary<int, string> mypairs = new Dictionary<int, string>() { { 1,"one"},{10,"ten" } };
           // mypairs.Add(1,"One");
            //mypairs.Add(10, "Ten");
            //mypairs.Add(100, "Hundred");
            Console.WriteLine($"Count is {mypairs.Count}");
            Console.WriteLine($"value is {mypairs[10]}");
                if(mypairs.Remove(10))
            {
                Console.WriteLine($"Count is {mypairs.Count}");
            }
                foreach(var v in mypairs.Keys)
            {
                Console.WriteLine($"Key is {v} and Value is {mypairs[v]}");
            }
        }
    }
}
