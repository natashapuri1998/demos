﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class MultiDimArrayDemo
    {
        static void Main()
        {
            int[,] nums = { { 10, 20, 30 }, { 40, 50, 60 } };
            int[,] nums1=new int[,] { { 10, 20, 30 }, { 40, 50, 60 } };
            int[,] nums2 = new int[2, 3];

            for(int i=0; i<2;i++)
            {
                for(int j=0;j<3;j++)
                {
                    Console.Write("{0}\t", nums[i, j]);
                }
                Console.WriteLine();
            
            }
        }
    }
}
