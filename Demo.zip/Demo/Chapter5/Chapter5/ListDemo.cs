﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class ListDemo
    {
        static void Main()
        {
          //List < int > myList= new List<int>();
            IList<int> myList = new List<int>();
            myList.Add(10);
            myList.Add(20);
            myList.Add(30);
            Console.WriteLine($"Count is {myList.Count}");
            foreach(int  temp in myList)
            {
                Console.WriteLine(temp);
            }
            if( myList.Remove(20))
            {
                Console.WriteLine($"Count is {myList.Count}");
            }
            Console.WriteLine("After rwemmoving 20:");
            foreach (int temp in myList)
            {
                Console.WriteLine(temp);
            }
            Console.ReadLine();
        }
    }
}
