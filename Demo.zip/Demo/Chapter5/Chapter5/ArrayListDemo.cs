﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter5
{
    class ArrayListDemo
    {
        static void Main()
        {
            ArrayList std = new ArrayList();
            std.Add(100);
            std.Add("Scott");
            std.Add("scott@gmail.com");
            std.Add('N');
            std.Add(true);
            std.Capacity = std.Count;
            Console.WriteLine("Total Count is {0} Capacity {1}", std.Count,std.Capacity);
            foreach(var temp in std)
            {
                Console.WriteLine(temp);
            }

            std.Remove("Scott");
            std.Capacity = std.Count;
            Console.WriteLine("After removing name:");
            foreach (var temp in std)
            {
                Console.WriteLine(temp);
            }
            Console.WriteLine("Total Count is {0} Capacity {1}", std.Count, std.Capacity);
            Console.WriteLine("100 is there? {0}", std.Contains(100));
            std.Clear();
            Console.WriteLine("After claering all elements");
            std.Capacity = std.Count;
            Console.WriteLine("Total Count is {0} Capacity {1}", std.Count, std.Capacity);
        }
    }
}
