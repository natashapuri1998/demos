﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace Chapter9
{
    class FileInfoDemo
    {
        static void Main()
        {
            FileInfo f = new FileInfo("try.txt");
            if(f.Exists)
            {
                Console.WriteLine($"File Full path: {f.FullName}");
                Console.WriteLine($"File Name : {f.Name}");
                Console.WriteLine($"File Extension : {f.Extension}");
                Console.WriteLine($"File Size : {f.Length} bytes");
                Console.WriteLine($"File Attributes : {f.Attributes}");
                Console.WriteLine($"File Creation Time : {f.CreationTime}");
                Console.WriteLine($"File Last Accessed Time : {f.LastAccessTime}");
              
            }

            if (f.Exists)
            {
                f.CopyTo(@"D:\TestFileInfo.txt",true);
                Console.WriteLine("File Copied Successfully");
            }

           /* if(f.Exists)
            {
                f.MoveTo(@"D:\try.txt");
                Console.WriteLine("File Moved Successfully");
            }*/

            if(f.Exists)
            {
                f.Delete();
                Console.WriteLine("File Deleted Successfully");
            }
            Console.ReadLine();
        }
    }
}
