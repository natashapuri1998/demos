﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Chapter9
{
    class Program
    {
        static void Main(string[] args)
        {
            //StreamWriter sw = new StreamWriter(@"D:\try.txt");  Absolute path
            StreamWriter sw = new StreamWriter("try.txt",true); //relative path
            sw.WriteLine("New Text Message Appended");
            sw.Close();
            Console.WriteLine("File has Written Successfully");
        }
    }
}
