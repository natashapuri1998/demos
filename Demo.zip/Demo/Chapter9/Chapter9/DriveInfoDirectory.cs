﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Chapter9
{
    class DriveInfoDirectory
    {
        static void Main ()
        {
            DriveInfo drive = new DriveInfo("D:");
            //if (drv.IsReady)
            //{
            //    Console.WriteLine($"Drive Name : {drv.Name}");
            //    Console.WriteLine($"Drive Volume Name : {drv.VolumeLabel}");
            //    Console.WriteLine($"Total Size : {drv.TotalSize} bytes");
            //    Console.WriteLine($"Total Free Space : {drv.TotalFreeSpace} bytes");
            //    Console.WriteLine($"Drive Type : {drv.DriveType}");
            //    Console.WriteLine($"Drive Format : {drv.DriveFormat}");
            //}

          foreach(DriveInfo drv in  DriveInfo.GetDrives())
            {
                if (drv.IsReady)
                {
                    Console.WriteLine($"Drive Name : {drv.Name}");
                    Console.WriteLine($"Drive Volume Name : {drv.VolumeLabel}");
                    Console.WriteLine($"Total Size : {drv.TotalSize} bytes");
                    Console.WriteLine($"Total Free Space : {drv.TotalFreeSpace} bytes");
                    Console.WriteLine($"Drive Type : {drv.DriveType}");
                    Console.WriteLine($"Drive Format : {drv.DriveFormat}");
                }
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}
