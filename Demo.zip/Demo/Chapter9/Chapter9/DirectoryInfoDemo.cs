﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Chapter9
{
    class DirectoryInfoDemo
    { 
        
        static void Main()
        {
            DirectoryInfo dir = new DirectoryInfo("MyFolder");
            if(!dir.Exists)
            {
                dir.Create();
                Console.WriteLine("Directory Created Successfully");
            }
            if(dir.Exists)
            {
                Console.WriteLine($"Full Name : {dir.FullName}");
                Console.WriteLine($"Name : {dir.Name}");
                Console.WriteLine($"Created Time : {dir.CreationTime}");
                Console.WriteLine($"Last Access Time : {dir.LastAccessTime}");
            }
            //if(dir.Exists)
            //{
            //    dir.Delete();
            //    Console.WriteLine("Directory Deleted Successfully");
            //}
            if (dir.Exists)
            {
                foreach(DirectoryInfo d in dir.GetDirectories())
                {
                    Console.WriteLine($"{d.Name} is deleted");
                    d.Delete();
                }
               
            }
            Console.ReadLine();
        }
    }
}
