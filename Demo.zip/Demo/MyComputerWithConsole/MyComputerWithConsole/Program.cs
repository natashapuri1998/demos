﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MYCOMPUTER;

namespace MyComputerWithConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Software s = new Software("Application Software", "MS-WORD", 2019);
            Console.WriteLine($"{ s.Display()}");
            Console.WriteLine ($"{ s.TroubleShoot()}");
        }
    }
}
