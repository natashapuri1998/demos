﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class NestedIfDemol
    {
        static void Main()
        {
            Console.WriteLine("Enter the highest Qualification in (UG|PG)");
            string Qualification = Console.ReadLine();
            Console.WriteLine("Enter Experience in Months");
            int Months = Convert.ToInt32(Console.ReadLine());
            if (Qualification == "PG")
            {
                if (Months >= 12)
                {
                    Console.WriteLine("You are eligible for interview");
                }
                else
                {
                    Console.WriteLine("Exp should be greater than or equal to 12 months");
                }
            }
            else
            {
                Console.WriteLine("Qualification should be PG");
            }
            Console.ReadLine();
        }
    }
}
