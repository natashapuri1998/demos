﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class SwitchDemo
    {
        static void Main()
        {
            Console.WriteLine("Enter Item:(Food| Services| Oranaments)");
            string Item = Console.ReadLine();
            switch(Item)
            {
                case "Food":   Console.WriteLine("5%");
                    break;
                case "Services":  Console.WriteLine("8%");
                    break;
                case "Ornaments":  Console.WriteLine("12%");
                    break;
                default: Console.WriteLine("Invalid Item");
                    break;
            }
        }

    }
}
