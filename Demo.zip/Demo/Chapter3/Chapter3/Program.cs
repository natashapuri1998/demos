﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Annual Income in Rupees:");
            int AnnualIncome = Convert.ToInt32(Console.ReadLine());
            if(AnnualIncome>=250000)
            {
                Console.WriteLine("You are liable to pay I.T");
            }
            else
            {
                Console.WriteLine("You are not liable to pay I.T");
            }
            Console.ReadLine();
                
                
        }
    }
}
