﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class TernaryDemo
    {
        static void Main()
        {
            Console.WriteLine("Enter Annual Income in Rupees:");
            int AnnualIncome = Convert.ToInt32(Console.ReadLine());
            string result=AnnualIncome >= 250000 ? "You are liable to pay I.T" : 30000.ToString();
            Console.WriteLine(result);
            Console.ReadLine();
        }
    }
}
