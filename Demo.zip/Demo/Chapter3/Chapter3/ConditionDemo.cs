﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class ConditionDemo
    {
        static void Main()
        {
            Console.WriteLine("Enter the highest Qualification in (UG|PG)");
            string Qualification = Console.ReadLine();
            Console.WriteLine("Enter Experience in Months");
            int Months = Convert.ToInt32(Console.ReadLine());
            if(Qualification.ToLowerInvariant()=="PG"  &&  Months>=12)
            {
                Console.WriteLine("You are Eligible for Interview");
            }
            else
            {
                Console.WriteLine("You are not Eligible for Interview");
            }
            Console.ReadLine();
        }
    }
}
