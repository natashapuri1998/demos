﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter3
{
    class GSTDemo
    {
        static void Main()
        {
            Console.WriteLine("Enter the (Food | Services | Oranaments)");
            string Item = Console.ReadLine();
            if(Item=="Food")
            {
                Console.WriteLine("1%");
            }
            else if(Item=="Services")
            {
                Console.WriteLine("4%");
            }
            else if(Item=="Ornaments")
            {
                Console.WriteLine("12%");
            }
            else
            {
                Console.WriteLine("Invalid Item");
            }
            Console.ReadLine();

            Console.WriteLine("Enter the name of Item");
            Console.ReadLine();
            Console.WriteLine("Enter the number of Item");
            int no = Convert.ToInt32(Console.ReadLine());

           

        

                
                    
        }
    }
}
