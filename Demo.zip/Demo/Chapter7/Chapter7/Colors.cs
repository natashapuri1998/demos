﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter7
{
    enum Colors
    {
        red=120,green=200,blue=red
    }
    enum Color1
    {
        red=Colors.green,green=200,blue=Colors.blue
    }
    enum GST
    {
        Maharashtra=27,Gujarat=24,Delhi=12,UP=32,AP=40,Karnataka=36
    }
}
