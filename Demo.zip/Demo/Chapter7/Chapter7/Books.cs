﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter7
{
    class Books
    {
        int ISBN = 123;
        string Name = "C# 4.0";
    }

    struct Book
    {
        int ISBN;
        string BookName;
        string AuthorName;
        public Book(int ISBN, string BookName, string AuthorName)
        {
            this.ISBN = ISBN;
            this.BookName = BookName;
            this.AuthorName = AuthorName;
        }

        public string Display()
        {
           return string.Format("Book ISBN={0} Name={1} Author Name={2}", ISBN, BookName, AuthorName);
        }
    }
}
