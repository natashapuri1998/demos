﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter7
{   struct MyDate
        {
            public struct MyMonth
            {
                public enum Months
                {
                    Jan = 1, Feb = 2, Mar = 3, Apr = 4, May = 5, June = 6, July = 7, Aug = 8, Sept = 9, Oct = 10, Nov = 11, Dec = 12
                }
            }
            public struct MyYear
            {
                public enum Years
                {
                    Year1 = 2019, Year2 = 2020, Year = 2021
                }
            }
        }
  


    class NestedStructDisplay
    {
        static void Main()
        {
            // Console.WriteLine(MyDate.MyMonth.Months.Mar.GetHashCode());

            Console.WriteLine("********************Months**************************");
            foreach (string name in Enum.GetNames(typeof(MyDate.MyMonth.Months)))
            {
                Console.WriteLine(name);
            }
            Console.WriteLine("********************Values**************************");
            foreach (int Code in Enum.GetValues(typeof(MyDate.MyMonth.Months)))
            {
                Console.WriteLine(Code);
            }
            Console.ReadLine();
        }
    }
}
