﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter7
{
    class EnumDemo
    {
        static void Main()
        {
            // Enum.
            //  Console.WriteLine(Colors.red.GetHashCode()); //Convert.ToInt32(Colors.red);
            //  Console.WriteLine(Colors.blue.GetHashCode());
            // Console.WriteLine(Color1.red.GetHashCode());
            // Console.WriteLine(Color1.blue.GetHashCode());
            // Console.WriteLine(Color1.green.GetHashCode());
            //Console.WriteLine(GST.Maharashtra.GetHashCode());
            Console.WriteLine("********************Names**************************");
            foreach(string name in Enum.GetNames(typeof(GST)))
            {
                Console.WriteLine($"Name of State is:{name}");
            }
            Console.WriteLine("********************Values**************************");
            foreach (int Code in Enum.GetValues(typeof(GST)))
            {
                Console.WriteLine(Code);
            }
            Console.ReadLine();
        }
    }
}
