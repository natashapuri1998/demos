﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class MultiLevelInheritDemo
    {
        static void Main()
        {
            NOKIA1100 nk = new NOKIA1100();
            Console.WriteLine( nk.Calling());
            Console.WriteLine( nk.SMS());
            Console.WriteLine( nk.Radio());
            Console.WriteLine( nk.MP3());
        }
    }
}
