﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    static class Employee
    {
        static Employee()
        {
            Console.WriteLine("Default Constructor Of Employee");
        }
        public static string Details(int EmpCode,string Name)
        {
return string.Format("Employee Code is {0} and Name is {1}",EmpCode,Name);
            
        }
    }

    class StaticDemo
    {
        static void Main()
        {
            Console.WriteLine( Employee.Details(100,"Tiger"));
            Console.ReadLine();
        }
    }
}
