﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class HierarchicalDemo
    {
        static void Main()
        {
            NOKIA2700 nk = new NOKIA2700();
            Console.WriteLine(nk.Calling());
            Console.WriteLine(nk.Camera());
            Console.WriteLine(nk.MP4());
            Console.ReadLine();
        }
    }
}
