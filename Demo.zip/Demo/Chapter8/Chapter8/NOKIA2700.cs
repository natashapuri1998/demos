﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class NOKIA2700:MobilePhone
    {
        public NOKIA2700()
        {
            Console.WriteLine("Default Constructor of NOKIA2700");
        }

        public string MP4()
        {
            return "MP4 Calling from NOKIA2700";
        }

        public string Camera()
        {
            return "Camera Calling from NOKIA2700";
        }
    }
}
