﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class FuncOverrideDemo
    {
        static void Main()
        {
            MyMath2 m = new MyMath2();
            Console.WriteLine(m.Increment(10));
            Console.ReadLine();   
        }
    }
}
