﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    abstract class Vehicle
    {
        
        public Vehicle()
        {
            Console.WriteLine("Default Constructor of Vehicle");
        }

        public string Start()
        {
            return "Starting Vehicle";
        }

        public string Stop()
        {
            return "Stoping  Vehicle";
        }

        public abstract string Start(string type);

    }


    partial  class FourWheeler : Vehicle
    {
        //suv
        public FourWheeler()
        {

        }
        public override string Start(string type)
        {
            return $"This will start using {type}";
        }
    }

    partial class FourWheeler
    {
        //xuv
        public FourWheeler(int x)
        {

        }
    }


    class AbstractDemo 
    {
        static void Main()
        {
            FourWheeler TataIndica = new FourWheeler();
            Console.WriteLine(TataIndica.Start());
            Console.WriteLine(TataIndica.Stop());
            Console.WriteLine(TataIndica.Start("key"));
            Console.ReadLine();
        }
    }

}
