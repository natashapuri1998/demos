﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class NOKIA1400 : MobilePhone
    {
        public NOKIA1400()
        {
            Console.WriteLine("Default Constructor of Mobile Phone");
        }
        public string Radio()
        {
            return "Calling Radio for NOKIA1400";
        }
        ~NOKIA1400()
        {
            Console.WriteLine("Garbage is collected for NOKIA1400 instance");
        
                }
    }
}
