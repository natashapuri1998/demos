﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    interface IWIFI
    {
        string StartWIFI();
        string StopWIFI();
    }

    class NOKIALUMIA : MobilePhone,IWIFI
    {
public string StartWIFI()
        {
            return "Starting WIFI";
        }

       public string StopWIFI()
        {
            return "Stopping WIFI";
        }
    }

    class NOKIALUMIA2 : NOKIALUMIA
    {
        public string PushMessage()
        {
            return "Calling from NOKIALUMIA2.PushMeassge()";
        }
    }

    class InterfaceDemo
    {
        static void Main()
        {
            IWIFI i = new NOKIALUMIA();
            NOKIALUMIA i1 = new NOKIALUMIA();
            Console.WriteLine(i1.StartWIFI());
            Console.WriteLine(i1.StopWIFI());
            Console.WriteLine(i.StartWIFI());
            Console.WriteLine(i.StopWIFI());
            NOKIALUMIA2 i3 = new NOKIALUMIA2();
            Console.WriteLine( i3.StartWIFI());
            Console.WriteLine( i3.StopWIFI());
        }
    }

   

}
