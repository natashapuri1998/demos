﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class FunOverloadDemo
    {
        static void Main()
        {
            MyMath m = new MyMath();
           Console.WriteLine(m.Add(20, 30));
            Console.WriteLine(m.Add("Hello", "World"));
            Console.ReadLine();
        }
    }
}
