﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class SingleInheritanceDemo
    {
        static void Main()
        {
            NOKIA1400 nk = new NOKIA1400();
           Console.WriteLine( nk.AboutMobile());
           Console.WriteLine( nk.Calling());
           Console.WriteLine( nk.SMS());
        }

    }
}
