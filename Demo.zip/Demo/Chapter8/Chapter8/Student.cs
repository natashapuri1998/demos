﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class Student
    {
        public string Gender {  get; set; }
        private int RollNo;
        private string Name;
        //private SchoolName;


        public int StudRollNo
        {
            get
            {
                RollNo++;
                return RollNo; 
            }
            set
            {
                if (value <= 0)
                {
                    Console.WriteLine("Invalid Roll No");
                }
                else
                {
                    RollNo = value;
                }
            }
        }

        public string StudName
        {
            get
            {
                return Name;
            }
            set
            {
                Name = value;
            }
        }

        public string SchoolName
        {
            get
            {
                return "M2M";
            }
        }
    }
}
