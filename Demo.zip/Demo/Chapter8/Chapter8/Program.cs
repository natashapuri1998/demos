﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class Program
    {
        static void Main(string[] args)
        {
            CreateMobile();
            //GC.Collect();
            Console.ReadLine();
        }

        public static  void CreateMobile()
        {
           // MobilePhone m = new MobilePhone();
            MobilePhone m1 = new MobilePhone(1234,"NOKIA7","ABPBJ12344");
            //  Console.WriteLine(m1.AboutMobile());
            Console.WriteLine(m1.ToString());
        }
    }
}
