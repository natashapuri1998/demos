﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class MobilePhone
    {
        int ModelNo;
        string MobileName;
        string IMEINo;
        public MobilePhone()
        {
            Console.WriteLine("Default Constructor of MobilePhone.");
        }
        public MobilePhone(int ModelNo, string MobileName, string IMEINo)
            {
            this.ModelNo = ModelNo;
            this.MobileName = MobileName;
            this.IMEINo = IMEINo;
            }

        public string AboutMobile()
        {
            return string.Format("ModelNo= {0} Name= {1} IMEINo= {2}",ModelNo,MobileName,IMEINo);
        }
        public string Calling()
        {
            return "This is Calling from Mobile Phone";
        }
        public string SMS()
        {
            return "Sending Message from Mobile Phone";
        }

        public override string ToString()
        {
            return string.Format("ModelNo= {0} Name= {1} IMEINo= {2}", ModelNo, MobileName, IMEINo);
        }
        ~MobilePhone()
        {
            Console.WriteLine("Garbage is Collected for MobilePhone instance");
        }
    }
}
