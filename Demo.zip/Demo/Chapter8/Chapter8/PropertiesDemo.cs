﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class PropertiesDemo
    {
        static void Main()
        {
            //  ArrayList arr = new ArrayList();
            // arr.Capacity = 45;
            Student stud = new Student() {StudRollNo = 100 ,StudName = "Scott" };
           // stud.StudRollNo = 0;
            //stud.StudName = "Scott";
            // stud.SchoolName
            Console.WriteLine("{0} {1}",stud.StudRollNo,stud.StudName);
            Console.ReadLine();
        }
    }
}
