﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter8
{
    class FunctionShadowing
    {
        static void Main()
        {
            MyMath2 m = new MyMath2();
            Console.WriteLine( m.Add(20.6, 50.6));
            Console.ReadLine();
        }
    }
}
