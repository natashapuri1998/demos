﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter4
{
    class ForEachDemo
    {
        static void Main()
        {
            string[] names = { "Sachin","Rahul","Saurav","Zaheer","Virat"};
            foreach(string temp in names)
            {
                Console.WriteLine(temp);
            }
            Console.ReadLine();
        }
    }
}
