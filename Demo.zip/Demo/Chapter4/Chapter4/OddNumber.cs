﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter4
{
    class OddNumber
    {
        static void Main()
        {
            int[] array = { 20,45,18,36,67,89,91};
            foreach(int temp in array)
            {
                if(temp%2!=0)
                {
                    Console.WriteLine(temp);
                }
                Console.ReadLine();
            }
        }
    }
}
