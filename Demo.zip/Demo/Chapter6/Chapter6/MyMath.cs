﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class MyMath
    {
        public void Message()
        {
            Console.WriteLine("This is text meassge");
        }

        public int Add(int num1,int num2)
        {
            return num1/num2;
        }

        public double Add(double d1, double d2)
        {
            return d1 + d2;
        }

        public int Increment(int x)  //by value
        {
            x++;
            return x;
        }

        public int Increment(ref int x)   //by reference
        {
            x++;
            return x;
        }

        public int MyFunction(out int x)
        {
            x = 10;
            int y = 100;
            return y;
        }

        public int OutValues(out int x,out int y)
        {
            x = 20;
            y = 30;
            int z = 10;
            return z;
        }

        public double GstValue(double proamt,double per, out double gstamt)
        {
            gstamt = (proamt*(per/100));
            double total = proamt + gstamt;
            return total;
            
            
        }

        public string  Size(int height,int width=1,string msg="Size is:")
        {
      
            return string.Format("{0} {1}",msg,height * width);
        }

        public void marks(params int[] mrks)
        {
            foreach(int temp in mrks)
            {
                Console.WriteLine(temp);
            }
        }
    }
}
