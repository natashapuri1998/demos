﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class InvalidStudentRollNo:Exception
    {
        public InvalidStudentRollNo():base("Student Roll No and Student name should not be Empty")
            {

            }

    }

    class StudentValidate
    {
        public void ValidateRollNo(string Name,int rollno)
        {
            if(Name =="" && rollno<100)
            {
                throw new InvalidStudentRollNo();
            }
        }
    }

    class Student
    {
        static void Main()
        {
            try
            {
                StudentValidate stud = new StudentValidate();
                stud.ValidateRollNo("", 10);

            }
            catch(InvalidStudentRollNo ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }
        

    }
}
