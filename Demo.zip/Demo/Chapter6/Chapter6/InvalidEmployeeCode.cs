﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class InvalidEmployeeCode:Exception
    {
        public InvalidEmployeeCode():base("Invalid Employee Code")
        {

        }

       

    }
}
