﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class Employee
    {
        public void PrintName(string Name)
        {
            if(Name =="")
            {
                throw new NullReferenceException("Employee name is null");
            }
        }
        public void ValidateEmpCode(int empcode)
        {
            if (empcode <= 0)
            {
                throw new InvalidEmployeeCode();
            }
        }

    }
}
