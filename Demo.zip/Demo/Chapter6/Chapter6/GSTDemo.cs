﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class GSTDemo
    {
        static void Main()
        {
            MyMath m = new MyMath();
            double productamt = 2000;
            double per=5;
            double gstamt;
            Console.WriteLine( m.GstValue(productamt, per,out gstamt));
            Console.WriteLine(gstamt);
       
        }
    }
}
