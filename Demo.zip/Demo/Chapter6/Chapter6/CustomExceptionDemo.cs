﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class CustomExceptionDemo
    {
        static void Main()
        {
            try
            {
                Employee emp = new Employee(); ;
                emp.ValidateEmpCode(0);
            }
            catch(InvalidEmployeeCode ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }
    }
}
