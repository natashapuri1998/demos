﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class Program
    {
        static void Main(string[] args)
        {
            MyMath m = new MyMath();
            m.Message();
            int num1 = 10, num2 = 20;
            int sum=m.Add(num1, num2);
            Console.WriteLine(sum);
        }
    }
}
