﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class SettingDemo
    {
      //  public int sum; // Instance variable
        static void Main()
        {
            Login();
            UserDetails();
        }
        public static void Login()
        {
            Chapter6.Properties.Settings1.Default.userName="Scott";
        }
        public static void UserDetails()
        {
            string name=Chapter6.Properties.Settings1.Default.userName;
            Console.WriteLine("Welcome : {0}", name);
        }
/*public static  void MyFunc(int x)
        {
            if(true)
            {
                int y = 20;
            }
        }
*/        public void MyRecurFun(int x)
        {
            if(x<=10)
            {
                Console.WriteLine(x);
                x++;
                MyRecurFun(x);
            }
        }
    }
}
