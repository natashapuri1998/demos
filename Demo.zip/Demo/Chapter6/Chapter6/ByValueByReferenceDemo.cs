﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class ByValueByReferenceDemo
    {
        static void Main()
        {
            MyMath m = new MyMath();
            int num = 99;
           // int.TryParse();
            Console.WriteLine(m.Increment(ref num));
            Console.WriteLine(num);
        }
    }
}
