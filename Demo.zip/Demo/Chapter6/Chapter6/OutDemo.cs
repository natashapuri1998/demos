﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class OutDemo
    {
        static void Main()
        {
            MyMath m = new MyMath();
            int num;
            Console.WriteLine(m.MyFunction(out num));
            Console.WriteLine(num);
            int num1, num2;
            Console.WriteLine(m.OutValues(out num1, out num2));
            Console.WriteLine(num1);
            Console.WriteLine(num2);
        }
    }
}
