﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class OptionalParamDemo
    {
        static void Main()
        {
            MyMath m = new MyMath();
            Console.WriteLine( m.Size(20,msg:"This is answer"));
        }
    }
}
