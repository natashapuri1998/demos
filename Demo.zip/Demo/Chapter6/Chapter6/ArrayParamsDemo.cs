﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter6
{
    class ArrayParamsDemo
    {
        static void Main()
        {
            MyMath m = new MyMath();
            m.marks(60, 70, 80, 90);
            Console.ReadLine();
        }
    }
}
