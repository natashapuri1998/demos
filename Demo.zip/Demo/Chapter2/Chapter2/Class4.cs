﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class Class4
        // ObjectDemo
    {
        static void Main()
        {
            object obj = 10, obj1 = "abc", obj2 = 3, obj3 = 'A', obj4 = true;
            Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}", obj,obj1, obj2, obj3, obj4);
            Console.ReadLine();

        }
    }
}
