﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
        /// <summary>
        /// This function prints a text message.
        /// </summary>
        public void Message()
        {
            Console.WriteLine("Hello World");
        }
        /// <summary>
        /// This function accepts text and prints text.
        /// </summary>
        /// <param name="str">simple text</param>
        /// <returns></returns>
        public string Message(string str)
        {
            return str;
        }
    }
}
