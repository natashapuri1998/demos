﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class BoxingDemo
    {
        static void Main()
        {
            int i = 30;
            Object MyObj = i;
            Console.WriteLine(MyObj);
            Console.ReadLine();
        }
    }
}
