﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class VarDemo
    {
        static void Main()
        {

            var v = 70;
            int[] nums = { 10,20,30,40,50};
            var v1 = nums;
            Console.WriteLine(v);
            foreach (var temp in v1)
            {
                Console.WriteLine(temp);

            }
            int num = 30;
            Console.WriteLine(num++);
            Console.ReadLine();

        }
    }
}
