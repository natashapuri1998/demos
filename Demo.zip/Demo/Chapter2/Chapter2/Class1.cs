﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Chapter2
{
    class Class1
    {
        static void Main()
        {
            
                Program p = new Program();
                p.Message();
                Console.WriteLine(p.Message("Hello World"));
                Console.ReadLine();
         
        }
    }
    class Class3:Class1
    {

    }
}
