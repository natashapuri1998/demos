﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class ConstDemo
    {
        static void Main()
        {
            const double PI = 3.14;//must be initialized
            //PI=3.15;  can't assign
            int r = 5;
            double abc = r * r * PI;
            Console.WriteLine(abc);
            Console.ReadLine();

      
        }
    }
}
