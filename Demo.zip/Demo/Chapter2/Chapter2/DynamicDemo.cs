﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class DynamicDemo
    {
        static void Main()
        {
            dynamic num=20;
            Console.WriteLine("type of num is {0}",num.GetType());
            string str = "abc";
            Console.WriteLine("type of str is {0}",str.GetType());
            Console.ReadLine();
        }
    }
}
