﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class ImplicitCastDemo
    {
        static void Main()
        {
            int num = 50;
            double d = num;
            Object obj = d;
            Console.WriteLine(d);
            Console.ReadLine();
        }
    }
}
