﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter2
{
    class IsDemo
    {
        static void Main()
        {
            int num = 10;
            int num1 = 30;
            object num2 = 33;
            Console.WriteLine(num1 is string);
            Console.WriteLine(num is int);
            Console.WriteLine(num2 is int);
            Class1 c1 = new Class1();
            Class3 c2 = new Class3();
            Console.WriteLine(c2 is Class1);

            Console.ReadLine();
        }
    }
}
