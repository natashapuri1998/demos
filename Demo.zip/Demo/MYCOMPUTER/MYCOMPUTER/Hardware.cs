﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MYCOMPUTER
{
   public class Hardware
    {
        string DeviceType;
        string DeviceName;
        int DeviceId;
        public Hardware(string DeviceType,string DeviceName,int DeviceId)
        {
            this.DeviceType = DeviceType;
            this.DeviceName = DeviceName;
            this.DeviceId = DeviceId;
        }

        public string Display()
        {
            return $"Device Type={DeviceType} Name={DeviceName} Id={DeviceId}";
        }
    }
}
