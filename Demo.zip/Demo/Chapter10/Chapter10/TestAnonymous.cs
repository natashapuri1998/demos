﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter10
{
    class TestAnonymous
    {
        static void Main()
        {
            List<Employee> emplist = new List<Employee>()
            { new Employee{ ID=101,Name="Scott",Gender="Male"},
            new Employee{ ID=102,Name="Tiger",Gender="Male"},
            new Employee{ ID=103,Name="Marry",Gender="Female"}
            };
            Predicate<Employee> employeePredicate = new Predicate<Employee>(GetEmployee);
            Employee emp = emplist.Find(x=>employeePredicate(x));
            Console.WriteLine($"ID={emp.ID} Name={emp.Name} Gender={emp.Gender}");
            Console.ReadLine();
        }
      
        public static bool GetEmployee(Employee emp)
        {
            return emp.ID == 103;
        }
    }
}
