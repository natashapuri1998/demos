﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter10
{
    class Program
    {
        public delegate void Print(int value);
        static void Main(string[] args)
        {
            Print printDel = new Print(PrintNumber);
           // printDel(100);
            printDel += PrintRupees;
            printDel -= PrintRupees;
            printDel(500000);
        }

        public static void PrintNumber(int num)
        {
            Console.WriteLine($"Number is {num}");
        }
        public static void PrintRupees(int rupees)
        {
            Console.WriteLine($"Rupees is {rupees}");
        }

    }
}
