﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter10
{
    /// <summary>
    /// Anonymous Function Demo
    /// </summary>
    class AnonymousFunDemo
    {
        public delegate void Print(int value);
        static void Main()
        {
            Print print = delegate (int val)
              {
                  Console.WriteLine($"I am from Anonymous Function {val}");
              };
            print(100);
        }
    }
}
