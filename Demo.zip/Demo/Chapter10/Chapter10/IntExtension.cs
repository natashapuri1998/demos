﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter10
{
   public static class IntExtension
    {
        public static bool IsGreaterThan(this int i,int value)
        {
            return i > value;
        }
    }

    class TestExtensionMethod
    {
        static void Main()
        {
            int i = 400;
            bool result = i.IsGreaterThan(100);
            Console.WriteLine(result ? "Greater": "Smaller");
            Console.ReadLine();
        }
    }
}
