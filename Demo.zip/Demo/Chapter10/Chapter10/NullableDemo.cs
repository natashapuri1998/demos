﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter10
{
    class NullableDemo
    {
        static void Main()
        {
            //  Nullable<int> num=null;
            //Nullable<int> num1 = 50;
            //Nullable<int>num3 = num + num1;
            int? num = null;
            if (num.HasValue)
            {
                Console.WriteLine(num);
            }
            else
            {
                Console.WriteLine("object is null");
            }
            Console.WriteLine(num.GetValueOrDefault());
            Console.ReadLine();
        }
    }
}
