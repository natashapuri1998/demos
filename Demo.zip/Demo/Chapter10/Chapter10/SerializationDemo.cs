﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Chapter10
{
    class SerializationDemo
    {
        static void Main()
        {
            //   DoSerialization();
            DoDeserialization();
            Console.ReadLine();
        }

        public static void DoSerialization()
        {
            //declare object to be serialized
            Employee emp = new Employee();
            emp.ID = 100;
            emp.Name = "Scott";
            emp.Gender = "Male";
            FileInfo f = new FileInfo("employee.dat");
            Stream stream = f.Open(FileMode.Create);
            BinaryFormatter b = new BinaryFormatter();
            b.Serialize(stream, emp);
            Console.WriteLine("emp object is serialized");
        }

        public static void DoDeserialization()
        {
            Employee emp = new Employee();
            FileInfo f = new FileInfo("employee.dat");
            Stream stream = f.Open(FileMode.Open);
            BinaryFormatter b = new BinaryFormatter();
            emp= (Employee)b.Deserialize(stream);
            Console.WriteLine($"ID={emp.ID} Name={emp.Name} Gender={emp.Gender}");
        }
    }
}
