﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter10
{
    public static class PostiveExtension
     {
        public static void isPostive(this int i,int value)
        {
            if(i>0)
            {
                Console.WriteLine("No is Positive ");
                i += value;
                Console.WriteLine(i);

            }
            else
            {
                Console.WriteLine("No is Negative");
            }
        }
    }

    class PositiveExtensionMethod
    {
        static void Main()
        {
            int i = 20;
            i.isPostive(30);
        }

    }
}
