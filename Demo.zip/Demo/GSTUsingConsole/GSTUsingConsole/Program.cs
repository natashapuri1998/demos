﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSTCALCULATION;

namespace GSTUsingConsole
{
    class Program
    {
        
        static void Main(string[] args)
        { 
            
            GST g = new GST();
            Console.WriteLine("Enter Amount");
            double amt = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Percentge");
            double per = Convert.ToDouble(Console.ReadLine());
            double gst;
            Console.WriteLine ("Total Amount : {0}",g.Total(amt,per,out gst));
            Console.WriteLine("GST : {0}",gst);
            Console.ReadLine();
        }
    }
}
