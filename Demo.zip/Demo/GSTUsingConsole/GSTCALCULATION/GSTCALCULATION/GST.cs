﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSTCALCULATION
{
    public class GST
    {
       
        public double Total(double amount,double per,out double gst)
        {
            gst = (amount * per) / 100;
            return amount + gst;
        }
    }
}
